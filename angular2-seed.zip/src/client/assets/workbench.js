(function (mod) {
  if (typeof exports == "object" && typeof module == "object") // CommonJS
    module.exports = mod();
  else if (typeof define == "function" && define.amd) // AMD
    return define([], mod);
  else // Plain browser env
    (this || window).WorkBench = mod();
})(function () {
  "use strict";
  var id = Math.floor(Math.random() * (10000 * 10000));
  var getTemplate = function () {
    return '<div><workbench-angular-component></workbench-angular-component></div>' + // Angular component we will event with observable
      '<div id="' + id + '"></div>'; // Existing component div container rendered with angular
  };

  var registerBridge = function (bridge) {
    this.bridge = bridge;
  }

  // Using the words "Component" and "Widget" interchangably.
  var initNonAngularComponent = function () {
    var workbenchAngularComponent = document.getElementById(id);
  };

  var initAngularComponent = function (observable) {

  };

  var addAngularComponent = function () {
    var angularContainer = document.getElementById("angular-app");
    // var newChild = document.createElement('workbench-angular-component');
    var newChild = document.createElement('div');
    this.bridge.addComponent("test", document.body.appendChild(newChild));
  };

  return {
    'registerBridge': registerBridge,
    'getTemplate': getTemplate,
    'initNonAngularComponent': initNonAngularComponent,
    'initAngularComponent': initAngularComponent,
    'addAngularComponent': addAngularComponent
  };
});