export * from './services/name-list.service';

