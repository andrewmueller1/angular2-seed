import {Component} from 'angular2/core';

@Component({
  selector: 'sd-about',
  templateUrl: 'app/+about/components/about.component.html',
  styleUrls: ['app/+about/components/about.component.css']
})
export class AboutComponent {}
