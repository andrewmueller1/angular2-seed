declare module 'tildify' {
  function tildify(path: string): string;
  module tildify {}
  export = tildify;
}