import {DIST_DIR} from '../../config';
import {clean} from '../../utils';

export = clean(DIST_DIR)
