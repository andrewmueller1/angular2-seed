import {PROD_DEST, TMP_DIR} from '../../config';
import {clean} from '../../utils';

export = clean([PROD_DEST, TMP_DIR])
