import {watch} from '../../utils';

export = watch('build.e2e')
